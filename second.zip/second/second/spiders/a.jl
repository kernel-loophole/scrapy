{"1": null}
{"2": "Fazl, Zardari, Shahbaz discuss no-trust motion at luncheon"}
{"3": "IHC stops govt from making arrests under Section 20 of PECA ordinance"}
{"4": "PM Imran Khan embarks on two-day visit to Russia"}
{"5": "PAK vs AUS: PCB announces updated Test Squad"}
{"6": "Inside story of meeting between Shahbaz Sharif and Asif Zardari"}
{"7": "Big blow to Multan Sultans as Tim David tests COVD-19 positive"}
{"8": "Journalist Athar Mateen\u2019s murderer arrested from Balochistan: official"}
{"9": "MQM-P urges govt to withdraw PECA ordinance"}
{"10": "PSL\u2019s top performers clash today in qualifier"}
{"11": "Matric exams to begin on May 17, Inter exams on June 15"}
{"12": "Margalla foothills likely site for cricket stadium in Islamabad"}
{"13": "Rashid advises PM to mend ties with Tareen"}
{"14": "Pakistan revises COVID-19 policy for inbound passengers"}
{"15": "Anoushey Ashraf talks about worst disagreement with Yasir Hussain "}
{"16": "Leonardo DiCaprio invests in French brand"}
{"17": "Khlo\u00e9 Kardashian to drag Blac Chyna back to court in assault lawsuit: reports"}
{"18": "The Weeknd locks lips with ex Bella Hadid's friend on 32nd birthday bash"}
{"19": "Cillian Murphy turns atomic scientist in Christopher Nolan's 'Oppenheimer' "}
{"20": "BTS announces 2022 Las Vegas Residency plans at Allegiant Stadium"}
{"21": "Taylor Swift, Joe Alwyn are officially engaged: Report"}
{"22": "Dua Lipa thanks fans after winning at BRITS Awards 2022"}
{"23": "Kate Middleton slide video takes the internet by storm"}
{"24": "Adele makes PDA-filled appearance with boyfriend Rich Paul in Cleveland"}
{"25": "\u2018Vikings: Valhalla\u2019 series premieres on Netflix, brings more adventures to screen"}
{"26": "Matthew Perry to spill details about Jennifer Aniston-Brad Pitt divorce?"}
{"27": "Kylie Jenner, Travis Scott fans are convinced THIS is their baby boy's name"}
{"28": "Princess Charlene receiving 'specialised' care outside Monaco: source"}
{"29": "Rider On The Storm"}
{"30": "The art of printing blocks"}
{"31": "Deceptive diets"}
{"32": "In conversation with Khushi Maheen"}
{"33": "Behind the miniature strokes\u2026"}
{"34": " Madhuri Dixit responds to online criticism over her Instagram reels"}
{"35": "Alia Bhatt reacts to marriage rumours with Ranbir Kapoor"}
{"36": "Attaullah Esakhelvi\u2019s daughter Laraib Atta bags Oscar nomination"}
{"37": "Security forces kill 10 terrorists in Balochistan IBO"}
{"38": "PM Imran Khan embarks on two-day visit to Russia"}
{"39": "PAK vs AUS: PCB announces updated Test Squad"}
{"40": "Princess Diana's words of wisdom to Prince William's on first school day revealed"}
{"41": "Adele's hint about baby 'caused awkward silence' between her and Rich Paul"}
{"42": "Queen Elizabeth growing \u2018thinner and frailer\u2019 as Palace frantically \u2018monitors\u2019 covid-19"}
{"43": "BTS\u2019 Jungkook makes first appearance on Billboard\u2019s Hot 100 with \u2018Stay Alive\u2019"}
{"44": "Liam Payne travels 10k miles to play golf post pledge to reduce carbon use "}
{"45": "EU looks to end data hoarding by companies"}
{"46": "Anna Sorokin slams Rachel Williams of \u2018exploiting\u2019 former friendship for \u2018minutes of fame\u2019"}
{"47": "Fazl, Zardari, Shahbaz discuss no-trust motion at luncheon"}
{"48": "Actress Jaida Benjamin found \u2018unharmed\u2019 a week after disappearing in Los Angeles"}
{"49": "Elton John performs in New York hours after scary private jet accident "}
{"50": "Britney Spears to splurge on new house after regaining control of finances"}
{"51": "Scarlett Johansson announces launch date of skincare brand The Outset"}
{"52": "TikTok star Addison Rae set to star in Hollywood film after delivering Netflix hit "}
{"53": "Lindsay Lohan surprises fans with an iconic line from \u2018The Parent Trap\u2019"}
{"54": "Kareena Kapoor shares loved-up picture from Kapoor's get together "}
{"55": "\u2018Two Broke Girls\u2019 Kat Dennings breaks emotional proposal by fianc\u00e9 Andrew W.K."}
{"56": "Deepika Padukone reveals Salman Khan was first person to offer her a movie"}
{"57": "Prince Harry, Meghan Markle to not bow, curtsy to Queen Consort Camilla "}
{"58": "Aiman Khan celebrates as she surpasses 10 million followers on Instagram "}
{"59": "Kim Kardashian's 'SNL' monologue gets featured at Kanye West's concert"}
{"60": "Inside story of meeting between Shahbaz Sharif and Asif Zardari"}
{"61": "Jesy Nelson drops major hint of her upcoming collab with will.i.am: pics"}
{"62": "Anoushey Ashraf talks about worst disagreement with Yasir Hussain "}
{"63": " Drew Barrymore goes makeup-free to celebrate 47th birthday: pic"}
